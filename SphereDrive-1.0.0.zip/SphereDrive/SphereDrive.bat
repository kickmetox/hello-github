@echo off
setlocal
cd /d "%~dp0"
if not exist "%~dp0Python\pythonw.exe" (
    echo SphereDrive wurde nicht vollstaendig entpackt.
    echo Python\pythonw.exe fehlt neben dieser Datei.
    pause
    exit /b 1
)
start "" "%~dp0Python\pythonw.exe" "%~dp0SphereDrive.launch.pyw" %*
exit /b 0
