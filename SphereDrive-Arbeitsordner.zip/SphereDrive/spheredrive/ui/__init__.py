"""Grafische Oberfläche von SphereDrive."""
