# InstantLens Doc — Fonctionnalités (fr)

- UI i18n DE/EN/FR/RU/ES/ZH/PT/AR/IT — **2.6.17**
- Aide/Paramètres localized — **2.6.17**
- Handwriting PSM — **2.6.17**
- AI wizards — **2.6.16**
- OCR → Word Suite — **2.6.15**
- Farbmanagement RGB/CMYK, Bleed, Ebenen, Preflight, PDF/X — **2.6.19**
