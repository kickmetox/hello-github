# InstantLens Doc — Aide

Version **2.6.19**.

## Langue

DE · EN · FR · RU · ES · ZH · PT · AR · IT — Paramètres.

## Modules

Viewer · OCR · Scan · Annotations · Forms · Export · Wizards · Paramètres

Handwriting: Tesseract PSM hook.

[Fonctionnalités](./features.md) · [Info](./info.md)
