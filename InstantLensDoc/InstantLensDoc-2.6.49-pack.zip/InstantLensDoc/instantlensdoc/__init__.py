"""InstantLens Doc — Paket."""

__version__ = "2.6.49"
__series__ = "2.6"  # About-Branding Major — 2.6.49
__author__ = "Andreas Meyer <ame@sellerbach.de>"
APP_NAME = "InstantLens Doc"
