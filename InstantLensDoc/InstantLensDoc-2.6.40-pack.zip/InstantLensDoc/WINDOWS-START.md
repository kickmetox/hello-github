# InstantLens Doc 2.6.40 - Blank PDF View + Windows Build Guard

Produkt **2.6.40** auf Branch `cursor/instantlensdoc-2108` · [PR #3](https://github.com/kickmetox/hello-github/pull/3).

**Probleme:** Setup nur ~2.9 MB (kein PyInstaller-EXE); Hauptansicht weiss trotz Schnellvorschau; Thumb-Klick ohne Seitendarstellung.

**Root causes:** Pack 2.6.39 ohne `run_instantlensdoc.py` → PyInstaller-Entry fehlt → Inno Python-Fallback; `refresh()`-Fehler liess Canvas leer bei erfolgreichem Open; Thumb-Jump brach ab wenn Stack != pdf_view.

**Fix 2.6.40:** Entry im Pack; EXE-Guard vor Inno; `_ensure_page_painted` + Zoom-Fallback; Thumb-Jump aktiviert PDF-Stack und erzwingt Paint.

Hinweis: Parallel-Pack **2.6.41** (ScanTuxio) kann im Store liegen — Blank/Build-Fix ist **2.6.40**; ScanTuxio bitte auf 2.6.40 rebasen.

## EMPFOHLEN: Fresh-Dest Sync + Build + Verify

```powershell
cd D:\AI_Temp

$Docs = "$env:LOCALAPPDATA\Cursor\AgentStores\cursor_agent_stores\bc-b08b150e-66b9-4e56-8bf8-50c583a73b7e\files\docs"
Copy-Item -Force "$Docs\InstantLensDoc-2.6.40-pack.zip" .\InstantLensDoc-2.6.40-pack.zip
Copy-Item -Force "$Docs\sync-ild.ps1" .\sync-ild.ps1

powershell -ExecutionPolicy Bypass -File .\sync-ild.ps1 `
  -LocalPack .\InstantLensDoc-2.6.40-pack.zip `
  -Dest D:\AI_Temp\InstantLensDoc-2640 `
  -SkipStart

cd D:\AI_Temp\InstantLensDoc-2640
# Entry muss existieren:
Test-Path .\run_instantlensdoc.py
powershell -ExecutionPolicy Bypass -File .\build-windows.ps1
# Verify EXE (nicht FileNotFound):
Test-Path .\dist\InstantLensDoc\InstantLensDoc.exe
(Get-Item .\dist\InstantLensDoc\InstantLensDoc.exe).Length / 1MB
powershell -ExecutionPolicy Bypass -File .\scripts\build-windows-installer.ps1
# Setup sollte >> 15 MB sein (typisch ~40-50 MB)
(Get-Item .\dist\InstantLensDoc-Setup-2.6.40.exe).Length / 1MB
Start-Process .\dist\InstantLensDoc\InstantLensDoc.exe
```

### UI-Verify Hauptansicht

1. PDF oeffnen (auch „Awesome Science Experiments…“ / grosse Docs).
2. Zentraler Viewport zeigt Seite 1 (nicht weiss).
3. Schnellvorschau-Thumb klicken → Seite wechselt und wird gerendert.
4. Fenstertitel: InstantLens Doc **2.6.40**.
