# InstantLens Doc 2.6.20 — Windows startbar (Python-Layout)

## Schnellstart (64-Bit empfohlen)

1. Python **3.10+ 64-Bit** installieren (python.org oder Microsoft Store).
2. Dieses Paket nach z. B. `D:\AI_Temp\InstantLensDoc` entpacken.
3. Abhängigkeiten:

```bat
cd /d D:\AI_Temp\InstantLensDoc
python -m pip install -r requirements.txt
run.bat
```

Oder non-interactive: `run.bat --yes`

## Keygenerator

```bat
run-keygen.bat
```

CLI: `python -m keygen kunde@example.com`  
Prüfen: `python -m keygen --verify "ILD1...."`

Keys: Trial 28 Tage · Lizenzkeys 32 Tage (30+2), Format `ILD1.<payload>.<sig>` (HMAC).  
Kontakt: ame@sellerbach.de

## EXE-Build (optional, auf Windows x64)

```powershell
powershell -ExecutionPolicy Bypass -File .\build-windows.ps1
```

Ergebnis: `dist\InstantLensDoc\InstantLensDoc.exe` (+ `InstantLensKeygen.exe`).  
Installer: `installer\build-installer.ps1`

## Desktop-/Startmenü-Shortcuts

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\install-ild.ps1
```

Keygen-Shortcut wird angelegt, wenn `run-keygen.bat` vorhanden ist.

## Scripting (Python / PowerShell)

```bat
python -m ild --help
run-ild.bat pages dokument.pdf
powershell -ExecutionPolicy Bypass -File .\scripts\ild.ps1 license generate kunde@example.com
```

Anleitung: siehe Store-Doc ``instantlensdoc-scripting.md`` bzw. In-App-Hilfe „Scripting“.

